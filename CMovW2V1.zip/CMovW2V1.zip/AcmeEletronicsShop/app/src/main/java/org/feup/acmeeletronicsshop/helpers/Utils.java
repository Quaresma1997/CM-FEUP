package org.feup.acmeeletronicsshop.helpers;

public class Utils {

    public static final String url = "https://a722be3a.ngrok.io";

    public static final String PREFS_NAME = "AcmeEletronicsShop_Settings";

    public Utils() {
    }
}
